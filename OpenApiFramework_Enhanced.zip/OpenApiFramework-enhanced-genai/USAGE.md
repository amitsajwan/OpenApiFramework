## Usage Guide

How to use the framework.