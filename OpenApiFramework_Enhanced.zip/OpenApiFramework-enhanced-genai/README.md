
# LangGraph-Based Automated API Testing Framework

## Overview
Automates API testing using OpenAPI specifications with intelligent sequence execution, async workflows, and chatbot-based human intervention.

## Installation
```bash
git clone <repository-url>
cd api_testing_framework
pip install -r requirements.txt
```
...
    